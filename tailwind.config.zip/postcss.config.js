module.exports = {
    plugins: {
      "@tailwindcss/postcss": {}, // ✅ correct for Tailwind v4
    },
  };